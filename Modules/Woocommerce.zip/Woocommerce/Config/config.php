<?php

return [
    'name' => 'Woocommerce',
    'module_version' => "2.7"
];
