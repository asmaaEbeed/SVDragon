<?php
return [
    "connector_module"=>"Connector-Modul",
	"connector"=>"Connector",
	"create_client"=>"Client erstellen",
	"client_secret"=>"Client-Geheimnis",
	"clients"=>"Clients",
	"documentation"=>"Dokumentation",
];